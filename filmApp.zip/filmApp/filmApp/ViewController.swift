//
//  ViewController.swift
//  filmApp
//
//  Created by administrator on 19/10/2021.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var label2: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
           let url = URL(string: "https://api.tvmaze.com/shows")
        var x : Int = 0 ;
           let session = URLSession.shared
           let task = session.dataTask(with: url!, completionHandler: {
               data, response, error in
               do {
                if let jsonResult = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.mutableContainers) as? [[String:Any]] {
                    while(x<249){
                    if let movieObject = jsonResult[x] as? [String:Any] {
                                        let name = movieObject["name"] as! String
                                        print("name of movie: \(name)")
                                        
                    }
                        x += 1
                    }
                    //self.label2.text = resultsArray.firstObject as! String
                   }
               } catch {
                   print(error )
               }
           })
           task.resume()
   }


}

